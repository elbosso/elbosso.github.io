package de.elbosso.scratch.aop;

/**
 * Created by elbosso on 7/25/17.
 */
public class Worker
{
	public String greet() {
		HelloWorld helloWorld=new HelloWorld();
		return helloWorld.greet();
	}

}
