/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.elbosso.scratch.aop;

import org.codehaus.aspectwerkz.joinpoint.JoinPoint;
import org.codehaus.aspectwerkz.joinpoint.StaticJoinPoint;

public class MyAspect
{

	private final static org.slf4j.Logger CLASS_LOGGER =org.slf4j.LoggerFactory.getLogger(MyAspect.class);

	public Object aroundGreeting(JoinPoint joinPoint) throws Throwable
	{
		
		{
			CLASS_LOGGER.trace("around greeting...");
		}
		Object greeting = null;
		try
		{
			greeting = joinPoint.proceed();
		}
		catch (java.lang.Throwable exp)
		{
			CLASS_LOGGER.trace("callee: "+joinPoint.getCallee());
			CLASS_LOGGER.trace("caller: "+joinPoint.getCaller());
			exp.printStackTrace();
			greeting = "<yell>" + exp.getMessage() + "</yell>";
			throw exp;
		}
		
		{
			CLASS_LOGGER.trace("/around greeting...");
		}
		return greeting;
	}

	public void exceptGreeting(JoinPoint joinPoint) throws Throwable
	{
		
		{
			CLASS_LOGGER.trace("except greeting...");
		}
//		Object greeting = joinPoint.proceed();

//        return "<yell></yell>";
	}

	public void beforeGreeting(JoinPoint joinPoint)
	{
		
		{
			CLASS_LOGGER.trace("before greeting...");
		}
	}

	public void afterGreeting(JoinPoint joinPoint)
	{
		
		{
			CLASS_LOGGER.trace("after greeting...");
		}
	}
}
