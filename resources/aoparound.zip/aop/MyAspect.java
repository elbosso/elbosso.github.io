/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.elbosso.scratch.aop;

import org.codehaus.aspectwerkz.joinpoint.JoinPoint;
import org.codehaus.aspectwerkz.joinpoint.StaticJoinPoint;

public class MyAspect
{

	private final static org.apache.log4j.Logger CLASS_LOGGER = org.apache.log4j.Logger.getLogger(MyAspect.class);

	public Object aroundGreeting(JoinPoint joinPoint) throws Throwable
	{
		if (CLASS_LOGGER.isTraceEnabled())
		{
			CLASS_LOGGER.trace("around greeting...");
		}
		Object greeting = null;
		try
		{
			greeting = joinPoint.proceed();
		}
		catch (java.lang.Throwable exp)
		{
			CLASS_LOGGER.trace("callee: "+joinPoint.getCallee());
			CLASS_LOGGER.trace("caller: "+joinPoint.getCaller());
			exp.printStackTrace();
			greeting = "<yell>" + exp.getMessage() + "</yell>";
			throw exp;
		}
		if (CLASS_LOGGER.isTraceEnabled())
		{
			CLASS_LOGGER.trace("/around greeting...");
		}
		return greeting;
	}

	public void exceptGreeting(JoinPoint joinPoint) throws Throwable
	{
		if (CLASS_LOGGER.isTraceEnabled())
		{
			CLASS_LOGGER.trace("except greeting...");
		}
//		Object greeting = joinPoint.proceed();
//        System.out.println("/except greeting...");
//        return "<yell></yell>";
	}

	public void beforeGreeting(JoinPoint joinPoint)
	{
		if (CLASS_LOGGER.isTraceEnabled())
		{
			CLASS_LOGGER.trace("before greeting...");
		}
	}

	public void afterGreeting(JoinPoint joinPoint)
	{
		if (CLASS_LOGGER.isTraceEnabled())
		{
			CLASS_LOGGER.trace("after greeting...");
		}
	}
}
