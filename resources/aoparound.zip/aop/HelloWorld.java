/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.elbosso.scratch.aop;


import org.apache.log4j.Level;

public class HelloWorld {
 private final static org.apache.log4j.Logger CLASS_LOGGER = org.apache.log4j.Logger.getLogger(HelloWorld.class);
    public static void main(String args[])
	{

    	de.elbosso.util.Utilities.configureBasicStdoutLogging(Level.TRACE);
        HelloWorld world = new HelloWorld();
		Worker worker=new Worker();
		if(CLASS_LOGGER.isTraceEnabled())CLASS_LOGGER.trace(System.getProperty("aspectwerkz.definition.file"));
//		if(CLASS_LOGGER.isTraceEnabled())CLASS_LOGGER.trace(world.greet());
		if(CLASS_LOGGER.isTraceEnabled())CLASS_LOGGER.trace(world.toString());
		if(CLASS_LOGGER.isTraceEnabled())CLASS_LOGGER.trace(worker.greet());
    }
	public String greet() {
		long d=System.currentTimeMillis();
		if(d!=0)
			throw new java.lang.RuntimeException("huhu");
		return "Hello World!";
	}

}