/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package de.elbosso.scratch.aop;


import de.elbosso.util.Utilities;
import ch.qos.logback.classic.Level;

public class HelloWorld {
 private final static org.slf4j.Logger CLASS_LOGGER =org.slf4j.LoggerFactory.getLogger(HelloWorld.class);
    public static void main(String args[])
	{

    	Utilities.configureBasicStdoutLogging(Level.TRACE);
        HelloWorld world = new HelloWorld();
		Worker worker=new Worker();
		CLASS_LOGGER.trace(System.getProperty("aspectwerkz.definition.file"));
//		CLASS_LOGGER.trace(world.greet());
		CLASS_LOGGER.trace(java.util.Objects.toString(world));
		CLASS_LOGGER.trace(worker.greet());
    }
	public String greet() {
		long d=System.currentTimeMillis();
		if(d!=0)
			throw new java.lang.RuntimeException("huhu");
		return "Hello World!";
	}

}