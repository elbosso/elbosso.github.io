#!/bin/bash
echo '#######' decryption for "Arabella.Moeller@Baron-zu-Becker-Dietrich-Pfeiffer-UG.hm"
openssl smime -decrypt -in mail.eml -inkey receivers/Arabella.Moeller@Baron-zu-Becker-Dietrich-Pfeiffer-UG.hm.pem
echo '#######' signature decryption failure for "torsten.ludwigkrueger@roth-kraus-zimmermann-kraemer.pl"
openssl smime -decrypt -in mail.eml -inkey non-receivers/torsten.ludwigkrueger@roth-kraus-zimmermann-kraemer.pl.pem -out torsten.ludwigkrueger@roth-kraus-zimmermann-kraemer.pl_decrypted.eml
