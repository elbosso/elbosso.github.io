#!/bin/bash
echo '#######' decryption for "Christiane.Ludwig@Peters-Winkler-Schroeder-Dachdecker.asia"
openssl smime -decrypt -in mail.eml -inkey receivers/Christiane.Ludwig@Peters-Winkler-Schroeder-Dachdecker.asia.pem
echo '#######' signature decryption failure for "petra.zimmermann@zimmermann-hartmann-konzerte-ltd.it"
openssl smime -decrypt -in mail.eml -inkey non-receivers/petra.zimmermann@zimmermann-hartmann-konzerte-ltd.it.pem -out petra.zimmermann@zimmermann-hartmann-konzerte-ltd.it_decrypted.eml
