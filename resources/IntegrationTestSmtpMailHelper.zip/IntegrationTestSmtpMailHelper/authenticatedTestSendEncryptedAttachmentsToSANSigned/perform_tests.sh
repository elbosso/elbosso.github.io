#!/bin/bash
echo '######' decryption for "Kurt.Peters@Keller-Voigt-Schaefer-eG.uk"
openssl smime -decrypt -in mail.eml -inkey receivers/Kurt.Peters@Keller-Voigt-Schaefer-eG.uk.pem -out Kurt.Peters@Keller-Voigt-Schaefer-eG.uk_decrypted.eml
echo '#######' signature verification for "Kurt.Peters@Keller-Voigt-Schaefer-eG.uk"
openssl smime -verify -noverify -in Kurt.Peters@Keller-Voigt-Schaefer-eG.uk_decrypted.eml
echo '#######' signature decryption failure for "tomas.lorenz@moeller-renovierung.dk"
openssl smime -decrypt -in mail.eml -inkey non-receivers/tomas.lorenz@moeller-renovierung.dk.pem -out tomas.lorenz@moeller-renovierung.dk_decrypted.eml
