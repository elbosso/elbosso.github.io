#!/bin/bash
echo '#######' signature verification
openssl smime -verify -noverify -in mail.eml
