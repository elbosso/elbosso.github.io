#!/bin/bash
echo '#######' decryption for "Thorsten.Kuehn@Neumann-Weber-Spengel.tl"
openssl smime -decrypt -in mail.eml -inkey receivers/Thorsten.Kuehn@Neumann-Weber-Spengel.tl.pem
echo '#######' decryption for "Patrizia.Fischer@Vogel-Huber-Einzelhandel-GbR.vn"
openssl smime -decrypt -in mail.eml -inkey receivers/Patrizia.Fischer@Vogel-Huber-Einzelhandel-GbR.vn.pem
echo '#######' decryption for "JuergenIris.Schmid@Franke-eG.sg"
openssl smime -decrypt -in mail.eml -inkey receivers/JuergenIris.Schmid@Franke-eG.sg.pem
echo '#######' signature decryption failure for "elisabeth.jaeger@voigt-schubert-konzerte.dj"
openssl smime -decrypt -in mail.eml -inkey non-receivers/elisabeth.jaeger@voigt-schubert-konzerte.dj.pem -out elisabeth.jaeger@voigt-schubert-konzerte.dj_decrypted.eml
