#!/bin/bash
echo '######' decryption for "Babette.Beck@Winkler-Schroeder-Elektro-SE.tel"
openssl smime -decrypt -in mail.eml -inkey receivers/Babette.Beck@Winkler-Schroeder-Elektro-SE.tel.pem -out Babette.Beck@Winkler-Schroeder-Elektro-SE.tel_decrypted.eml
echo '#######' signature verification for "Babette.Beck@Winkler-Schroeder-Elektro-SE.tel"
openssl smime -verify -noverify -in Babette.Beck@Winkler-Schroeder-Elektro-SE.tel_decrypted.eml
echo '######' decryption for "Marc.Boehm@van-Engel-Kraemer-Schaefer-Fensterbau.us"
openssl smime -decrypt -in mail.eml -inkey receivers/Marc.Boehm@van-Engel-Kraemer-Schaefer-Fensterbau.us.pem -out Marc.Boehm@van-Engel-Kraemer-Schaefer-Fensterbau.us_decrypted.eml
echo '#######' signature verification for "Marc.Boehm@van-Engel-Kraemer-Schaefer-Fensterbau.us"
openssl smime -verify -noverify -in Marc.Boehm@van-Engel-Kraemer-Schaefer-Fensterbau.us_decrypted.eml
echo '######' decryption for "Oliver.KruegerFranke@Koch-zu-Huber-Meyer-KGaA.tf"
openssl smime -decrypt -in mail.eml -inkey receivers/Oliver.KruegerFranke@Koch-zu-Huber-Meyer-KGaA.tf.pem -out Oliver.KruegerFranke@Koch-zu-Huber-Meyer-KGaA.tf_decrypted.eml
echo '#######' signature verification for "Oliver.KruegerFranke@Koch-zu-Huber-Meyer-KGaA.tf"
openssl smime -verify -noverify -in Oliver.KruegerFranke@Koch-zu-Huber-Meyer-KGaA.tf_decrypted.eml
echo '#######' signature decryption failure for "mark.schaefer@koenig-sce.vc"
openssl smime -decrypt -in mail.eml -inkey non-receivers/mark.schaefer@koenig-sce.vc.pem -out mark.schaefer@koenig-sce.vc_decrypted.eml
