#!/bin/bash
echo '#######' decryption for "Paul.Jung@Baumann-Schreiber-Meyer-UG-Co-KG.vc"
openssl smime -decrypt -in mail.eml -inkey receivers/Paul.Jung@Baumann-Schreiber-Meyer-UG-Co-KG.vc.pem
echo '#######' decryption for "Horge.Koenig@Richter-Hochbau.asia"
openssl smime -decrypt -in mail.eml -inkey receivers/Horge.Koenig@Richter-Hochbau.asia.pem
echo '#######' decryption for "Susanne.Schmid@Lorenz-Koch-GbR.cl"
openssl smime -decrypt -in mail.eml -inkey receivers/Susanne.Schmid@Lorenz-Koch-GbR.cl.pem
echo '#######' signature decryption failure for "peter.hofmann@albrecht-schuster-entsorgung.dj"
openssl smime -decrypt -in mail.eml -inkey non-receivers/peter.hofmann@albrecht-schuster-entsorgung.dj.pem -out peter.hofmann@albrecht-schuster-entsorgung.dj_decrypted.eml
