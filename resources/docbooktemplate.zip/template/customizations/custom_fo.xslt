<?xml version='1.0'?> 
<xsl:stylesheet  
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
    xmlns:fo="http://www.w3.org/1999/XSL/Format"
    version="1.0"> 

<xsl:import href="/home/elbosso/src/language_java/resources/docbook-xsl-ns-1.76.1/fo/docbook.xsl"/> 

<xsl:param name="callout.icon.size" select="10"/>
<xsl:param name="callouts.extension" select="1"/>
<xsl:param name="highlight.source" select="1"/>
<xsl:param name="section.autolabel" select="1"/>
<!--xsl:template match="lineannotation">
  <fo:inline font-style="italic">
    <xsl:call-template name="inline.charseq"/>
  </fo:inline>
</xsl:template-->
</xsl:stylesheet> 
