#!/bin/sh

THRESHOLD=1

echo `basename $0` >&2
count=`systemctl --failed|grep "loaded units listed"|cut -d " " -f 1`
if [ $count -ge $THRESHOLD ]; then
	echo "Failed systemd modules ($count)"
	exit 1
fi
