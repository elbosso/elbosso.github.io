#!/bin/sh

PATTERN="transaction1\|updates1"

echo `basename $0` >&2
#yesterday=`TZ=CST+24 date +"%b %_d"`
today=`TZ=CST+24 date +"%b %_d"`
count=`cat /var/log/syslog |grep "$today"|grep -e $PATTERN|wc -l`
if [ $count -ne 0 ]; then
	echo "syslog today $PATTERN"
	exit 1
fi
