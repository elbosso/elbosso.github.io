#!/bin/sh

echo `basename $0` >&2

#if [ $? -ne 0 ]; then
	echo "error 2"
	exit 1
#fi
