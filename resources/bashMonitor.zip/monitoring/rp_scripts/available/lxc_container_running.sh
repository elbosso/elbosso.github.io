#!/bin/sh

echo `basename $0` >&2
containername=xenial-gui-operative
number=`lxc-ls --active --fancy|grep -P "(^|\s)\K${containername}(?=\s|$)"|wc -l)`
#echo $number
if [ $number -eq 0 ]; then
	echo "lxc container ${containername} not running"
	exit 1
fi
