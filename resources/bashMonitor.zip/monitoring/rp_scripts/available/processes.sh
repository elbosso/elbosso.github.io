#!/bin/sh

THRESHOLD=160

echo `basename $0` >&2
count=`ps aux|wc -l`
if [ $count -ge $THRESHOLD ]; then
	echo "processes"
	exit 1
fi
