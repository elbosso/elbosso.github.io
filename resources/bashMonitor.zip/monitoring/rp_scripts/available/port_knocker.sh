#!/bin/sh

HOST=localhost
PORT=22
#http://stackoverflow.com/a/9609247

echo `basename $0` >&2
nc -z $HOST $PORT
if [ $? -ne 0 ]; then
	echo "port $HOST:$PORT"
	exit 1
fi
