#!/bin/sh

THRESHOLD=100

echo `basename $0` >&2
count=`netstat -aun |wc -l`
if [ $count -ge $THRESHOLD ]; then
	echo "udp port count"
	exit 1
fi
