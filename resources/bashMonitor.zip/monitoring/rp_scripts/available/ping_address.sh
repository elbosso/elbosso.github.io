#!/bin/sh

echo `basename $0` >&2
ping -c 2 8.8.8.8  > /dev/null
if [ $? -ne 0 ]; then
	echo "ping address"
	exit 1
fi
