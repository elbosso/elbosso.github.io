#!/bin/sh

THRESHOLDPERCENTAGE=75

echo `basename $0` >&2

#http://www.netadmintools.com/art295.html
allocated=`cat /proc/sys/fs/file-nr|cut -f 1`
free=`cat /proc/sys/fs/file-nr|cut -f 2`
max=`cat /proc/sys/fs/file-nr|cut -f 3`
#echo $allocated>&2
#echo $free>&2
#echo $max>&2
used=$(( allocated-free ))
#echo $used>&2
percentageused=$(( $used*100/$max ))
if [ $? -ne 0 ]; then
	echo "filedescriptor count"
	exit 1
fi
