#!/bin/sh

THRESHOLDPERCENTAGE=75

echo `basename $0` >&2
total=`free -t |grep Mem:|cut -d : -f 2| sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'|cut -d\  -f 1`
used=`free -t |grep -|cut -d : -f 2| sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'|cut -d\  -f 1`
percentageused=$(( $used*100/$total ))
#echo $percentageused
if [ $percentageused -ge $THRESHOLDPERCENTAGE ]; then
	echo "memory"
	exit 1
fi
