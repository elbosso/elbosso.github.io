#!/bin/sh
#echo `basename $0` >&2
#echo "waiting for message body (CTRL-D ends it)..."
huhu=`env MAILRC=/dev/null -from=monitoring@hm-ag.de smtp=mail.ilmenau.net \
smtp-auth-user=monitoring@hm-ag.de smtp-auth-password=Yaish6it \
echo "type *" | mail -u monitoring 2> /dev/null`
echo "$huhu"
if [ ! "$huhu" ]; then
   echo "no mails"
   exit 1
else
    huhu=`echo "$huhu" | grep -A 1 "^HMI Status Mail"`
    if [ ! "$huhu" ]; then
        echo "no hmi status mails"
        exit 1
    else
#        echo "$huhu"
        huhu=`echo "$huhu" | grep -v "^HMI Status Mail" | grep -v "^--"`
        if [ ! "$huhu" ]; then
            echo "error parsing mails"
            exit 1
        else
        mkdir -p /root/maillogs
        t=`date +%T`
        d=`date +%F`
        echo "----- "$t" -----" >>/root/maillogs/$d.log
        echo $huhu >>/root/maillogs/$d.log
            #Set the field separator to new line
            IFS=$'\n'
            for item in $huhu
            do
#            echo "#"
#                echo "Item: $item"
#            echo "*"
#Achtung:
dat=`echo -n $item|sed 's/_/ /'`
                d=`date -d $dat 2>/dev/null`
                if [ $? -ne 0 ]; then
                    echo $item
                    exit 1
#                else
#                    echo $d
                fi
            done
        fi
    fi
fi
#|grep -A 1 "^HMI Status Mail"|grep -v "^HMI Status Mail" |grep -v "--"
#echo "type *" | mail -u monitoring |grep -A 1 "^HMI Status Mail"|grep -v "^HMI Status Mail" |grep -v "--"
#huhu=`echo "hallo" | cat `
#echo "--"
#echo $huhu
#env MAILRC=/dev/null -from=monitoring@hm-ag.de smtp=mail.ilmenau.net \
#smtp-auth-user=monitoring@hm-ag.de smtp-auth-password=Yaish6it \
#echo "d *" | mail -u hmadmin

#if [ $? -ne 0 ]; then
#        echo "template"
#        exit 1
#fi	
