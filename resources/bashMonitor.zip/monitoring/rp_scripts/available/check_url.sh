#!/bin/sh

URL="--no-check-certificate https://klapauzius"

echo `basename $0` >&2
rm out.html
wget $URL -O out.html > /dev/null 2>&1
if [ $? -ne 0 ]; then
	echo "url"
	exit 1
fi
