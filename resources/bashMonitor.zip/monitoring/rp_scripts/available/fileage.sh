#!/bin/sh

echo `basename $0` >&2

filename=/tmp/a
seconds=180
#echo  $(( (`date +%s` - `stat -L --format %Y $filename`)))
result=$(( (`date +%s` - `stat -L --format %Y $filename`) > ($seconds) ))
#echo $result
if [ $result -ne 0 ]; then
	echo "$filename older that $seconds!"
	exit 1
fi
