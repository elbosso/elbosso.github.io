#!/bin/sh

THRESHOLD=0.75

echo `basename $0` >&2
load=`iostat -c |tail -n 2|head -n 1|awk '{print $4}'`
comparisonresult=$(awk 'BEGIN{ print "'$THRESHOLD'"<="'$load'" }')
if [ $comparisonresult -eq 1 ]; then
	echo "io load"
	exit 1
fi
