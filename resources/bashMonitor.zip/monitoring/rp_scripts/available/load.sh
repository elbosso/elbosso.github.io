#!/bin/sh

THRESHOLD=0.75

echo `basename $0` >&2
load=`uptime | rev |cut -d : -f 1|rev|cut -d , -f 3| tr -d ' '`
#echo $load
comparisonresult=$(awk 'BEGIN{ print "'$THRESHOLD'"<="'$load'" }')
if [ $comparisonresult -eq 1 ]; then
	echo "load"
	exit 1
fi
