#!/bin/sh

echo `basename $0` >&2
ping -c 2 heise.de > /dev/null
if [ $? -ne 0 ]; then
	echo "ping name"
	exit 1
fi
