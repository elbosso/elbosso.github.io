#!/bin/sh

THRESHOLD=100

echo `basename $0` >&2
count=`netstat -atn |wc -l`
if [ $count -ge $THRESHOLD ]; then
	echo "tcp port count"
	exit 1
fi
